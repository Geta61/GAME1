package com.example.iubip_lectures.data.domain

enum class Choice {
    ROCK,
    PAPER,
    SCISSORS
}