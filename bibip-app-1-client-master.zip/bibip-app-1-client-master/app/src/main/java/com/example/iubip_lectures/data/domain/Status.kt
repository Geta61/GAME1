package com.example.iubip_lectures.data.domain

enum class Status {
    WIN,
    DRAW,
    LOSE
}